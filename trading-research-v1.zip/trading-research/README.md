# Trading Research

Primera versión funcional del laboratorio de trading.

## Incluye
- Dashboard con KPIs y equity.
- Registro manual de operaciones.
- Bloques cronológicos de 20 operaciones.
- Configuración editable de Setup, VD, NR, hipótesis y regímenes de riesgo.
- Importación inicial del formato delimitado por `|` generado por Ankora.
- Persistencia local en el navegador para validar el flujo antes de conectar Supabase.

## Cloudflare
La configuración usa Workers Static Assets y `npx wrangler deploy`.
No requiere build en esta primera versión.

## Próxima fase
- Supabase para persistencia real y multi-dispositivo.
- Storage permanente de screenshots.
- Parser robusto de Ankora con validación y vista previa.
- Laboratorio estadístico avanzado.
- Comparación contra universo total y filtros multidimensionales.
